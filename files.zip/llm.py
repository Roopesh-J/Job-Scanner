"""
llm.py — LLM provider abstraction.

All pipeline stages call generate() here.
To swap providers (e.g. to Claude), only this file needs to change.
"""

import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

_client = None

def _get_client() -> OpenAI:
    global _client
    if _client is None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise EnvironmentError("OPENAI_API_KEY not set in .env")
        _client = OpenAI(api_key=api_key)
    return _client


def generate(prompt: str, system: str = "", model: str = None, temperature: float = 0.0) -> str:
    """
    Send a prompt to the LLM and return the response text.

    Args:
        prompt:      The user message / main prompt.
        system:      Optional system message.
        model:       Model name. Defaults to OPENAI_MODEL env var or gpt-4o.
        temperature: Sampling temperature. Default 0.0 for reproducibility.

    Returns:
        Raw response string from the model.
    """
    model = model or os.getenv("OPENAI_MODEL", "gpt-4o")
    client = _get_client()

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=temperature,
    )

    return response.choices[0].message.content
