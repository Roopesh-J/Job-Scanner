"""
run.py — Job Intelligence Engine entry point.

Usage:
    python run.py                        # paste JD interactively
    python run.py --file path/to/jd.txt  # load from file
"""

import argparse
import json
import os
import sys
from datetime import datetime

from pipeline import ingest, capture, validate, repair, analyze


def save(artifact: dict, label: str, run_id: str):
    os.makedirs("outputs", exist_ok=True)
    path = f"outputs/{run_id}_{label}.json"
    with open(path, "w") as f:
        json.dump(artifact, f, indent=2)
    print(f"  [saved] {path}")


def print_analysis(analysis: dict):
    parsed = analysis.get("parsed")
    if not parsed:
        print("\n[!] Analysis parse failed. Raw output:\n")
        print(analysis.get("raw_output"))
        return

    print("\n" + "="*60)
    print("JOB INTELLIGENCE ENGINE — RESULTS")
    print("="*60)

    print(f"\n📋 SUMMARY\n{parsed.get('summary', 'N/A')}")

    print("\n✅ MUST-HAVES")
    for item in parsed.get("must_haves", []):
        print(f"  • {item['text']}  [{', '.join(item.get('source_ids', []))}]")

    print("\n⭐ NICE-TO-HAVES")
    for item in parsed.get("nice_to_haves", []):
        print(f"  • {item['text']}  [{', '.join(item.get('source_ids', []))}]")

    print("\n🛠  SKILL MAP")
    for category, skills in parsed.get("skill_map", {}).items():
        if skills:
            print(f"  {category.capitalize()}: {', '.join(skills)}")

    print("\n🎯 INTERVIEW TOPICS")
    for topic in parsed.get("interview_topics", []):
        print(f"  • {topic['topic']}  [{', '.join(topic.get('source_ids', []))}]")
        print(f"    → {topic['rationale']}")

    print("\n💬 QUESTIONS TO PREPARE")
    for q in parsed.get("prep_questions", []):
        print(f"  • {q}")

    print("\n❓ QUESTIONS TO ASK THEM")
    for q in parsed.get("questions_to_ask", []):
        print(f"  • {q}")

    print("\n💡 WHAT TO EMPHASIZE")
    for point in parsed.get("what_to_emphasize", []):
        print(f"  • {point}")

    print("\n" + "="*60)


def main():
    parser = argparse.ArgumentParser(description="Job Intelligence Engine")
    parser.add_argument("--file", type=str, help="Path to a .txt file with the job description")
    args = parser.parse_args()

    run_id = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    print(f"\n🚀 JIE run started — {run_id}\n")

    # Stage 1: Ingest
    print("[1/4] Ingesting...")
    if args.file:
        with open(args.file, "r") as f:
            raw = f.read()
        ingest_artifact = ingest(raw, source=f"file:{args.file}")
    else:
        print("Paste the job description. Enter a blank line followed by END when done:")
        lines = []
        while True:
            line = input()
            if line.strip() == "END":
                break
            lines.append(line)
        ingest_artifact = ingest("\n".join(lines), source="stdin")
    save(ingest_artifact, "1_ingest", run_id)

    # Stage 2: Capture
    print("\n[2/4] Capturing (extraction pass)...")
    capture_artifact = capture(ingest_artifact)
    save(capture_artifact, "2_capture", run_id)
    print(f"  {'✓ parsed' if capture_artifact['parse_success'] else '✗ parse failed'}")

    # Stage 3: Validate + repair
    print("\n[3/4] Validating...")
    validated = validate(capture_artifact)
    if not validated["valid"]:
        print(f"  ✗ errors: {validated['validation_errors']}")
        validated = repair(validated)
        if not validated["valid"]:
            print("  ✗ repair failed. Check outputs.")
            save(validated, "3_failed", run_id)
            sys.exit(1)
    print("  ✓ valid")
    save(validated, "3_validated", run_id)

    # Stage 4: Analyze
    print("\n[4/4] Analyzing...")
    analysis_artifact = analyze(validated)
    save(analysis_artifact, "4_analysis", run_id)
    print(f"  {'✓ done' if analysis_artifact['parse_success'] else '✗ parse failed'}")

    print_analysis(analysis_artifact)


if __name__ == "__main__":
    main()
