"""
pipeline.py — All pipeline stages: ingest, capture, validate, analyze.

Stages run in sequence:
  1. ingest   — normalize raw text, build source artifact
  2. capture  — extract structured data from JD text (LLM)
  3. validate — check structure, attempt repair if needed (LLM)
  4. analyze  — generate insights from capture artifact only (LLM)
"""

import re
import json
from datetime import datetime
from llm import generate


# ─────────────────────────────────────────────
# STAGE 1: INGEST
# ─────────────────────────────────────────────

def ingest(raw_text: str, source: str = "manual") -> dict:
    """Normalize and package raw JD text into an ingest artifact."""
    if not raw_text or not raw_text.strip():
        raise ValueError("Job description text is empty.")

    normalized = re.sub(r'\n{3,}', '\n\n', raw_text.strip())
    normalized = "\n".join(line.rstrip() for line in normalized.splitlines())

    return {
        "stage": "ingest",
        "source": source,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "raw_text": raw_text,
        "normalized_text": normalized,
        "char_count": len(normalized),
    }


# ─────────────────────────────────────────────
# STAGE 2: CAPTURE
# ─────────────────────────────────────────────

CAPTURE_SYSTEM = """
You are a precise job description extraction engine.

Your job is to extract structured information from a job description with maximum faithfulness.

Rules:
- Do NOT invent, infer, or add anything not present in the text.
- Prefer exact or near-exact phrasing from the source.
- If something is ambiguous or missing, use null or "unknown".
- Every requirement and responsibility must include an "evidence" field: a short direct quote from the JD.
- Modality: classify each requirement as "required", "preferred", or "unknown".

Respond ONLY with valid JSON. No explanation, no markdown fences.
""".strip()

CAPTURE_PROMPT = """
Extract the following from this job description and return as JSON matching the schema below.

JOB DESCRIPTION:
{jd_text}

JSON SCHEMA:
{{
  "meta": {{
    "title": "string or null",
    "company": "string or null",
    "location": "string or null",
    "remote_policy": "string or null"
  }},
  "responsibilities": [
    {{
      "id": "R01",
      "text": "exact or near-exact text from JD",
      "evidence": "short quote from JD"
    }}
  ],
  "requirements": [
    {{
      "id": "REQ01",
      "text": "exact or near-exact text from JD",
      "modality": "required | preferred | unknown",
      "evidence": "short quote from JD"
    }}
  ],
  "skills": [
    {{
      "id": "S01",
      "name": "skill or tool name",
      "modality": "required | preferred | unknown",
      "evidence": "short quote from JD"
    }}
  ],
  "other_notes": "any important details that don't fit above, or null"
}}

Return only valid JSON.
""".strip()

def capture(ingest_artifact: dict) -> dict:
    """Run the extraction pass on an ingest artifact."""
    prompt = CAPTURE_PROMPT.format(jd_text=ingest_artifact["normalized_text"])
    raw_output = generate(prompt=prompt, system=CAPTURE_SYSTEM, temperature=0.0)

    parsed, parse_error = None, None
    try:
        parsed = json.loads(raw_output)
    except json.JSONDecodeError as e:
        parse_error = str(e)

    return {
        "stage": "capture",
        "raw_output": raw_output,
        "parsed": parsed,
        "parse_error": parse_error,
        "parse_success": parsed is not None,
    }


# ─────────────────────────────────────────────
# STAGE 3: VALIDATE + REPAIR
# ─────────────────────────────────────────────

REQUIRED_KEYS = {"meta", "responsibilities", "requirements", "skills"}

def validate(capture_artifact: dict) -> dict:
    """Validate the parsed capture output. Returns artifact with valid + validation_errors fields."""
    errors = []

    if not capture_artifact.get("parse_success"):
        errors.append(f"JSON parse failed: {capture_artifact.get('parse_error')}")
        return {**capture_artifact, "valid": False, "validation_errors": errors}

    parsed = capture_artifact["parsed"]

    for key in REQUIRED_KEYS:
        if key not in parsed:
            errors.append(f"Missing required key: '{key}'")

    for list_key in ["responsibilities", "requirements", "skills"]:
        if list_key in parsed and not isinstance(parsed[list_key], list):
            errors.append(f"'{list_key}' should be a list")

    for item in parsed.get("responsibilities", []):
        if "id" not in item: errors.append(f"Responsibility missing 'id': {item}")
        if "text" not in item: errors.append(f"Responsibility missing 'text': {item}")

    for item in parsed.get("requirements", []):
        if "id" not in item: errors.append(f"Requirement missing 'id': {item}")
        if "text" not in item: errors.append(f"Requirement missing 'text': {item}")

    for item in parsed.get("skills", []):
        if "id" not in item: errors.append(f"Skill missing 'id': {item}")
        if "name" not in item: errors.append(f"Skill missing 'name': {item}")

    return {**capture_artifact, "valid": len(errors) == 0, "validation_errors": errors}


REPAIR_SYSTEM = """
You are a JSON repair assistant. Fix the broken JSON so it is valid and matches the original schema.
Return ONLY valid JSON, no explanation.
""".strip()

def repair(capture_artifact: dict) -> dict:
    """Attempt to repair an invalid capture artifact via LLM."""
    print("  [validate] Attempting repair...")
    repair_prompt = f"""
Fix this broken JSON and return only valid JSON.

BROKEN JSON:
{capture_artifact.get('raw_output', '')}

Errors:
{chr(10).join(capture_artifact.get('validation_errors', []))}
""".strip()

    repaired_raw = generate(prompt=repair_prompt, system=REPAIR_SYSTEM, temperature=0.0)

    repaired_parsed, repair_error = None, None
    try:
        repaired_parsed = json.loads(repaired_raw)
    except json.JSONDecodeError as e:
        repair_error = str(e)

    repaired = {
        **capture_artifact,
        "raw_output": repaired_raw,
        "parsed": repaired_parsed,
        "parse_error": repair_error,
        "parse_success": repaired_parsed is not None,
        "was_repaired": True,
    }
    return validate(repaired)


# ─────────────────────────────────────────────
# STAGE 4: ANALYZE
# ─────────────────────────────────────────────

ANALYZE_SYSTEM = """
You are a career coach and job analysis expert.

You will be given a structured capture artifact extracted from a job description.
Generate useful analysis outputs ONLY from what is present in this artifact.

Rules:
- Do NOT invent anything not in the capture.
- Reference item IDs (e.g. REQ01, R03, S02) when supporting claims.
- Be concise and practical — this is for a job seeker preparing to apply.

Respond ONLY with valid JSON. No explanation, no markdown fences.
""".strip()

ANALYZE_PROMPT = """
Given this capture artifact, produce an analysis in JSON format.

CAPTURE ARTIFACT:
{capture_json}

JSON SCHEMA:
{{
  "summary": "2-4 sentence plain-English summary of the role",
  "must_haves": [
    {{"text": "concise must-have", "source_ids": ["REQ01", "S02"]}}
  ],
  "nice_to_haves": [
    {{"text": "concise nice-to-have", "source_ids": ["REQ05"]}}
  ],
  "skill_map": {{
    "technical": ["skill1"],
    "soft": ["skill1"],
    "domain": ["skill1"],
    "tools": ["tool1"]
  }},
  "interview_topics": [
    {{"topic": "topic name", "rationale": "why it'll come up", "source_ids": ["R02"]}}
  ],
  "prep_questions": ["Question to prepare an answer for..."],
  "questions_to_ask": ["Question to ask the recruiter or HM..."],
  "what_to_emphasize": ["Key thing to highlight, grounded in the JD"]
}}

Return only valid JSON.
""".strip()

def analyze(validated_capture: dict) -> dict:
    """Run the analysis pass on a validated capture artifact."""
    if not validated_capture.get("valid"):
        raise ValueError(f"Cannot analyze invalid capture. Errors: {validated_capture.get('validation_errors')}")

    capture_json = json.dumps(validated_capture["parsed"], indent=2)
    prompt = ANALYZE_PROMPT.format(capture_json=capture_json)
    raw_output = generate(prompt=prompt, system=ANALYZE_SYSTEM, temperature=0.0)

    parsed, parse_error = None, None
    try:
        parsed = json.loads(raw_output)
    except json.JSONDecodeError as e:
        parse_error = str(e)

    return {
        "stage": "analyze",
        "raw_output": raw_output,
        "parsed": parsed,
        "parse_error": parse_error,
        "parse_success": parsed is not None,
    }
